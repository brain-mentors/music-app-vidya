// Arrow Functions (Short Hand Function)
const Header = ()=>{
    return (<h1>Music App</h1>)
}
export default Header;