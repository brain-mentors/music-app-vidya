import Header from "./Header"
import Song from "./Song"

const MusicPage = ()=>{
    return (
        <div>
    <Header/>
    <Song/>
    </div>
    )
}
export default MusicPage;