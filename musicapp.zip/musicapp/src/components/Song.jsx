import { useEffect, useState } from "react";
// Song Component - Function + JSX return
const Song =  ()=>{
    const [songs, setSongs] = useState([]);
    // function create for api call
    const makeApiCall = async ()=>{
        
        const URL = 'https://itunes.apple.com/search?term=daler mehndi&limit=25';
        // to make api call we use fetch
        const response = await  fetch(URL);
        // fetch gives response
        // response = Header + Body
       const data = await response.json();
       // response.json() - get the json and convert it into JS Object
       console.log('Data is ',data.results);
       setSongs(data.results); // Set in State
    }
    // It call when component mount
    useEffect(()=>{
        // API CALL
        makeApiCall();
         // API CALL (WEB API) (WEB Service)
   
    },[]);
   
    // fetch(URL); // Non - Blocking (Async)
    // const promise = fetch(URL);
    // promise.then().catch();
    return (
        <div>
        {songs.length==0 && <p>No Songs</p>}
       
        { songs.map(currentSong=>
        <div>
        <img src = {currentSong.artworkUrl100}/>
        <audio controls>
            <source src={currentSong.previewUrl} type="audio/mp3"/>
        </audio>
        <p>{currentSong.trackName}</p></div>)}
       
        
        </div>
        )
}
export default Song;