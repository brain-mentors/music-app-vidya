import ReactDOM from 'react-dom/client';
import App from './App';
/* 
Bridge file b/w index.html (Page) 
and App.js (First Component)
document = Html Page
*/
const htmlDiv = document.getElementById('root');
const root = ReactDOM.createRoot(htmlDiv);
root.render(<App/>); // JSX --> HTML