// Component - Function + JSX

import MusicPage from "./components/MusicPage";

// This is the Root Component (First Component)
function App(){

  return (<MusicPage/>)
}
export default App;